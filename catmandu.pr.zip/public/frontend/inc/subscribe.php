<section class="subscribe">
  <div class="subs-box clearfix">
      <div class="container">
          <div class="row">
            <form name="frmSubscribe" class="form-control no-pad" method="post" action="">
              <div class="subs-box">
                  <h3>Subscribe Now</h3>
                  <div class="subs-form">
                    <div class="row">
                      <div class="col-sm-8">
                        <input type="email" class="form-control" name="subsEmail" value="">
                      </div>
                      <div class="col-sm-4">
                        <input type="submit" class="btn btn-primary" name="btnSubmit" value="Submit">
                      </div>
                    </div>
                  </div>
              </div>
            </form>
          </div>
      </div>
  </div>
</section>

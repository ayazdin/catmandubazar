<div class="row mar-bot-30 featured">
  <div class="block-ttl auto-search col-sm-12"><h2><span>फिचर समाचार</span> <hr></h2></div>
  <div class="col-sm-4">
    <div class="wrap">
        <div class="f-top">
          <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
        </div>
        <div class="f-right">
            <h3>शालिक बन्यो निक्की हेडेनको, जुन ९ अब निक्की हेडेन डे</h3>
            <p>मोटो जीपी वर्ल्ड च्याम्पियनका पूर्व विजेता निक्की हेडेनको सालिक स्थापना गरिएको छ । हिजो अमेरिकाको</p>
            <a href="#" class="btn btn-danger home-btn">
              पुरा पढ्नुहोस् ...
            </a>
        </div>
        <div class="clear"></div>
    </div>
  </div>


  <div class="col-sm-4">
    <div class="wrap">
        <div class="f-top">
          <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
        </div>
        <div class="f-right">
            <h3>शालिक बन्यो निक्की हेडेनको, जुन ९ अब निक्की हेडेन डे</h3>
            <p>सवारी साधन गुडाउने पहिलो चक्का काठबाट बनाइएको थियो । त्यस पछि काठ माथिवाट फलामको रिङ्ग लगाइन्थ्यो ।</p>
            <a href="#" class="btn btn-danger home-btn">
              <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
              पुरा पढ्नुहोस् ...
            </a>
        </div>
        <div class="clear"></div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="wrap">
        <div class="f-top">
          <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
        </div>
        <div class="f-right">
            <h3>शालिक बन्यो निक्की हेडेनको, जुन ९ अब निक्की हेडेन डे</h3>
            <p>मोटो जीपी वर्ल्ड च्याम्पियनका पूर्व विजेता निक्की हेडेनको सालिक स्थापना गरिएको छ । हिजो अमेरिकाको</p>
            <a href="#" class="btn btn-danger home-btn">
              <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
              पुरा पढ्नुहोस् ...
            </a>
        </div>
        <div class="clear"></div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="wrap">
        <div class="f-top">
          <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
        </div>
        <div class="f-right">
            <h3>शालिक बन्यो निक्की हेडेनको, जुन ९ अब निक्की हेडेन डे</h3>
            <p>मोटो जीपी वर्ल्ड च्याम्पियनका पूर्व विजेता निक्की हेडेनको सालिक स्थापना गरिएको छ । हिजो अमेरिकाको</p>
            <a href="#" class="btn btn-danger home-btn">
              पुरा पढ्नुहोस् ...
            </a>
        </div>
        <div class="clear"></div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="wrap">
        <div class="f-top">
          <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
        </div>
        <div class="f-right">
            <h3>शालिक बन्यो निक्की हेडेनको, जुन ९ अब निक्की हेडेन डे</h3>
            <p>मोटो जीपी वर्ल्ड च्याम्पियनका पूर्व विजेता निक्की हेडेनको सालिक स्थापना गरिएको छ । हिजो अमेरिकाको</p>
            <a href="#" class="btn btn-danger home-btn">
              पुरा पढ्नुहोस् ...
            </a>
        </div>
        <div class="clear"></div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="wrap">
        <div class="f-top">
          <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
        </div>
        <div class="f-right">
            <h3>शालिक बन्यो निक्की हेडेनको, जुन ९ अब निक्की हेडेन डे</h3>
            <p>मोटो जीपी वर्ल्ड च्याम्पियनका पूर्व विजेता निक्की हेडेनको सालिक स्थापना गरिएको छ । हिजो अमेरिकाको</p>
            <a href="#" class="btn btn-danger home-btn">
              पुरा पढ्नुहोस् ...
            </a>
        </div>
        <div class="clear"></div>
    </div>
  </div>
</div>

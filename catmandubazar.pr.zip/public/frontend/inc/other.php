<div class="row mar-bot-30 featured">
  <div class="block-ttl auto-search col-sm-12">
    <h2><span>अन्य अटो समाचार</span> <hr></h2>
  </div>

  <div class="col-sm-6">
    <div class="wrap o-hight">
        <div class="o-left">
          <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
        </div>
        <div class="o-right">
            <h3>शालिक बन्यो निक्की हेडेनको, जुन ९ अब निक्की हेडेन डे</h3>
            <p></p>
            <a href="#" class="btn btn-danger home-btn">
              पुरा पढ्नुहोस् ...
            </a>
        </div>
        <div class="clear"></div>
    </div>
  </div>

  <div class="col-sm-6">
    <div class="wrap o-hight">
        <div class="o-left">
          <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
        </div>
        <div class="o-right">
            <h3>शालिक बन्यो निक्की हेडेनको, जुन ९ अब निक्की हेडेन डे</h3>
            <p></p>
            <a href="#" class="btn btn-danger home-btn">
              पुरा पढ्नुहोस् ...
            </a>
        </div>
        <div class="clear"></div>
    </div>
  </div>

  <div class="col-sm-6">
    <div class="wrap o-hight">
        <div class="o-left">
          <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
        </div>
        <div class="o-right">
            <h3>शालिक बन्यो निक्की हेडेनको, जुन ९ अब निक्की हेडेन डे</h3>
            <p></p>
            <a href="#" class="btn btn-danger home-btn">
              पुरा पढ्नुहोस् ...
            </a>
        </div>
        <div class="clear"></div>
    </div>
  </div>

  <div class="col-sm-6">
    <div class="wrap o-hight">
        <div class="o-left">
          <div class="ima" style="background-image:url(http://nepalauto.com/wp-content/uploads/2018/06/nicky-heyden-250x188.jpg)"></div>
        </div>
        <div class="o-right">
            <h3>शालिक बन्यो निक्की हेडेनको, जुन ९ अब निक्की हेडेन डे</h3>
            <p></p>
            <a href="#" class="btn btn-danger home-btn">
              पुरा पढ्नुहोस् ...
            </a>
        </div>
        <div class="clear"></div>
    </div>
  </div>


</div>

<div class="row mar-bot-30 price-list">
  <div class="block-ttl auto-search col-sm-12"><h2><span>मूल्य सूची खोज्नुहोस</span> <hr></h2></div>
  <div class="col-sm-12">
    <form class="needs-validation" novalidate="">
      <div class="row">
        <div class="col-md-4">
          <input type="text" class="form-control" name="company" id="company" placeholder="कम्पनी" value="">
        </div>
        <div class="col-md-4">
          <input type="text" class="form-control" name="model" id="model" placeholder="मोडेल" value="">
        </div>
        <div class="col-md-4">
          <button class="btn btn-primary" type="submit">खोज्नुहोस</button>
        </div>
      </div>
    </form>
  </div>
</div>

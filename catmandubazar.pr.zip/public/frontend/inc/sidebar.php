<div class="col-sm-3">
  <div class="side-ads">
    <img src="Total_AD1.jpg" alt="ads">
  </div>

  <div class="side-ads mar-v-20">
    <h2>लेखक बाट</h2>
    <div class="widget">
      <ul>
        <li><span>असार १,२०७५</span> <h3>टेस्ट राइड : नयाँ अवतारको शक्तिशाली डुएट</h3></li>
        <li><span>असार १,२०७५</span> <h3>उच्च कोटिको प्रिमियम एसयुभी : स्टेयरिङ समातेर गुडाउन थालेपछि फिल हुन्छ जसको सबलता</h3></li>
        <li><span>असार १,२०७५</span> <h3>आउदै छ यात्राको नयाँ प्रविधि, १२ मिनेटमै २४ किलोमिटर यात्रा गर्न सकिने</h3></li>
        <li><span>असार १,२०७५</span> <h3>हंसराज हुलासचन्द अब टायर व्यवसायमा, नेपाली बजारमा ल्यायो युरोग्रिप टायर</h3></li>
        <li><span>असार १,२०७५</span> <h3>नेपाल टेलिकमले ल्यायो परिमार्जित एप, प्याकेज खरिद गर्न र अन्य धेरै कार्य गर्न सकिने</h3></li>
      </ul>
    </div>
  </div>

  <div class="side-ads">
    <div class="fb-page" data-href="http://nepalauto.com/" data-tabs="timeline"
                data-small-header="false" data-adapt-container-width="true"
                data-hide-cover="false" data-show-facepile="true"></div>
  </div>

  <div class="side-ads">
    <img src="http://nepalauto.com/wp-content/uploads/2017/05/Hitco.jpg" alt="ads">
  </div>

  <div class="side-ads">
    <img src="Total_AD1.jpg" alt="ads">
  </div>

</div>
